   <footer>
    <?php echo '&copy' .date('Y') . '. The Noble Green';?>
    <a href="#" class="fa fa-facebook"></a>
    <a href="#" class="fa fa-twitter"></a>
    <a href="#" class="fa fa-linkedin"></a>
    
        </footer>