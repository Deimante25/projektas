<div class="coursetext">
            <h1>Courses</h1><br>
            <h3>We offer a variety of floral design courses and workshops</h3>
                <p>In the Floral Design Course, you will learn how to create many different styles of floral designs and flower arrangements the professional way.

                    Have you ever looked at a beautiful flower arrangement but had no idea how it was made?
                    We’ll show you exactly what types of flowers and foliage to use together to give the most impact.

                    It’s easy once you know how.

                    The course is set out so the absolute beginner can learn floristry.  If you already have experience in floral designing, you will find our course of great value to you in furthering your knowledge.

                    No one is born a floral designer. All skills have to be learnt and once you have this knowledge you will have it for a lifetime.</p>
                    <hr class="borderline">
        
        </div>    
        
            <div class="container">    
            <div class="box-courses">
            <img src="../app/images/plant.svg" alt="kursai">
             <div class="course-text">
            <h3>Intro 101</h3><br>
            <p>Turn your love of flowers and design into an exciting career or rewarding hobby. Learn the skills and techniques to make beautiful floral arrangements for your home, friends or a special occasion.<br><br>Learn wrapping, tying, arranging and other techniques that will allow you to create many gorgeous designs; such as hand tied posies, gift boxes, corsages, and arrangements for special occasions.</p>
            </div>
            </div>
        
                <div class="box-courses">
                    <img src="../app/images/bouquet.png" alt="garden">
                    <div class="course-text">
                    <h3>Event and Corporate Design</h3><br>
                    <p>Build on your basic floristry skills with the floral designers behind displays for world-famous hotels such as Claridges through to events such as the Vanity Fair Oscars party. <br><br>You'll be equipped with lots of practical advice by the attentive tutor team and instilled with creative and forward-thinking design ideas.</p>
                </div>
                </div>
                
                <div class="box-courses">
                    <img src="../app/images/cactus.png" alt="cactus">
                    <div class="course-text">
                    <h3>Terrarium Workshop</h3><br>
                    <p>Making its debut in January, join the immensely popular half-day terrarium class.<br><br>
                    Delve into the fascinating world of miniature microclimates on this terrarium half-day workshop. Housed within a stylish vessel, get hands-on and create your own botanical gem. The perfect addition to your home or handmade gift!</p>
                </div> 
                </div>
            </div>
        
            
            
            
      
        <div class="contactus">
        <div class="forma">
            <form id="contact" action="courses.php" method="post">
                <h3>Want to enroll in a course?</h3>
                <h4>Drop us a line</h4>
                <p><input type="text" name="vardas" placeholder="Your name..." required></p>
                <p><input type="email" name="email" placeholder="Your email..." required></p>
                <p><textarea placeholder="Your message..." name="message" required></textarea></p>
                <p><button name="submit" type="submit" id="contact-submit">Send</button></p>
            </form> 
            </div>      
        </div> 

