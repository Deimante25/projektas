<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Noble Green</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
    
 <body>   
    <header>
        <div class="container">
        <div id="logo">
            <a href="/green/index.php"><img src="../app/images/Logo2.png" style="max-width:100%;height:auto;" height="250" width="300" alt="logo"></a>
        </div>
        <nav>
          <ul>
            <li><a href="/green/index.php">Home</a></li>
            <li><a class="active" href="courses.php">Courses</a></li>
            <li><a href="/green/aboutus.php">About Us</a></li>
            <li><a href="/green/contacts.php">Contact Us</a></li> 
          </ul>  
        </nav>
        </div>
    </header>